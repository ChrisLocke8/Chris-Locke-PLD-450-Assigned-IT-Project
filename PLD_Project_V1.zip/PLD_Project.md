```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer

# Load the dataset
md = pd.read_csv(r'C:\Users\cbrya\Jupyter\ACG_Dataset_Train.csv', low_memory=False)

# Filter the dataset to include only rows where is_Deceased is equal to 1
filtered_md = md[md['is_Deceased'] == 1]

# Compute the correlation matrix for the filtered dataset
correlation_matrix = filtered_md.corr()

import seaborn as sns

sns.heatmap(md.corr(), cmap="YlGnBu")
plt.show()

# Step 1: Data Preprocessing
X = md.drop('is_Deceased', axis=1)  # Features
y = md['is_Deceased']  # Target variable

# Splitting the dataset into Train, Validation, and Test sets
X_train_val, X_test, y_train_val, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_train_val, y_train_val, test_size=0.2, random_state=42)

# Step 2: Data Imputation
imputer = SimpleImputer(strategy='mean')  # Create an imputer with strategy 'mean'
X_train_imputed = imputer.fit_transform(X_train)  # Fit the imputer on the training data and transform it
X_val_imputed = imputer.transform(X_val)  # Transform the validation data
X_test_imputed = imputer.transform(X_test)  # Transform the test data

# Step 3: Model Selection and Training
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train_imputed, y_train)  # Train the model using imputed training data

# Step 4: Model Evaluation
y_train_pred = model.predict(X_train_imputed)  # Predictions on the training data
y_val_pred = model.predict(X_val_imputed)  # Predictions on the validation data
y_test_pred = model.predict(X_test_imputed)  # Predictions on the test data

train_accuracy = accuracy_score(y_train, y_train_pred)  # Training accuracy
val_accuracy = accuracy_score(y_val, y_val_pred)  # Validation accuracy
test_accuracy = accuracy_score(y_test, y_test_pred)  # Test accuracy

print("Training Accuracy:", train_accuracy)
print("Validation Accuracy:", val_accuracy)
print("Test Accuracy:", test_accuracy)

```


    
![png](output_0_0.png)
    


    Training Accuracy: 1.0
    Validation Accuracy: 1.0
    Test Accuracy: 1.0
    


```python
md.describe(include='all')
md.shape
```




    (60000, 43)




```python
md.shape
```




    (60000, 43)




```python

```
